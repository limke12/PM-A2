/**
 * PROG2005 - Assignment 2 Part 1
 * TypeScript Inventory Management System
 */

type Category = 'Electronics' | 'Furniture' | 'Clothing' | 'Tools' | 'Miscellaneous';
type StockStatus = 'In Stock' | 'Low Stock' | 'Out of Stock';
type PopularStatus = 'Yes' | 'No';

interface InventoryItem {
    itemId: string;
    itemName: string;
    category: Category;
    quantity: number;
    price: number;
    supplierName: string;
    stockStatus: StockStatus;
    popularItem: PopularStatus;
    comment: string;
}

let inventory: InventoryItem[] = [];
let isEditing: boolean = false;
let editingItemId: string | null = null;
let currentSearchTerm: string = '';
let showingPopularOnly: boolean = false;

const itemForm = document.getElementById('itemForm') as HTMLFormElement;
const itemIdInput = document.getElementById('itemId') as HTMLInputElement;
const itemNameInput = document.getElementById('itemName') as HTMLInputElement;
const categorySelect = document.getElementById('category') as HTMLSelectElement;
const quantityInput = document.getElementById('quantity') as HTMLInputElement;
const priceInput = document.getElementById('price') as HTMLInputElement;
const supplierInput = document.getElementById('supplier') as HTMLInputElement;
const stockStatusSelect = document.getElementById('stockStatus') as HTMLSelectElement;
const popularItemSelect = document.getElementById('popularItem') as HTMLSelectElement;
const commentTextarea = document.getElementById('comment') as HTMLTextAreaElement;
const submitBtn = document.getElementById('submitBtn') as HTMLButtonElement;
const cancelEditBtn = document.getElementById('cancelEditBtn') as HTMLButtonElement;
const formTitle = document.getElementById('formTitle') as HTMLHeadingElement;
const searchInput = document.getElementById('searchInput') as HTMLInputElement;
const searchBtn = document.getElementById('searchBtn') as HTMLButtonElement;
const resetSearchBtn = document.getElementById('resetSearchBtn') as HTMLButtonElement;
const showAllBtn = document.getElementById('showAllBtn') as HTMLButtonElement;
const showPopularBtn = document.getElementById('showPopularBtn') as HTMLButtonElement;
const tableBody = document.getElementById('tableBody') as HTMLTableSectionElement;
const messageArea = document.getElementById('messageArea') as HTMLDivElement;
const confirmModal = document.getElementById('confirmModal') as HTMLDivElement;
const confirmDeleteBtn = document.getElementById('confirmDeleteBtn') as HTMLButtonElement;
const cancelDeleteBtn = document.getElementById('cancelDeleteBtn') as HTMLButtonElement;
const deleteItemNameSpan = document.getElementById('deleteItemName') as HTMLSpanElement;

let pendingDeleteId: string | null = null;

function showMessage(message: string, type: 'success' | 'error'): void {
    messageArea.textContent = message;
    messageArea.className = `message-area ${type}`;
    messageArea.style.display = 'block';
    setTimeout(() => {
        messageArea.style.display = 'none';
    }, 3000);
}

function isNotEmpty(value: string): boolean {
    return value.trim().length > 0;
}

function isUniqueId(id: string, excludeId?: string): boolean {
    return !inventory.some(item => item.itemId === id && item.itemId !== excludeId);
}

function isPositiveNumber(value: number): boolean {
    return !isNaN(value) && value >= 0;
}

function determineStockStatus(quantity: number): StockStatus {
    if (quantity <= 0) return 'Out of Stock';
    if (quantity < 5) return 'Low Stock';
    return 'In Stock';
}

function resetForm(): void {
    itemForm.reset();
    isEditing = false;
    editingItemId = null;
    submitBtn.textContent = '➕ Add Item';
    formTitle.textContent = '➕ Add New Item';
    cancelEditBtn.style.display = 'none';
    itemIdInput.disabled = false;
}

function populateFormForEdit(item: InventoryItem): void {
    itemIdInput.value = item.itemId;
    itemNameInput.value = item.itemName;
    categorySelect.value = item.category;
    quantityInput.value = item.quantity.toString();
    priceInput.value = item.price.toString();
    supplierInput.value = item.supplierName;
    stockStatusSelect.value = item.stockStatus;
    popularItemSelect.value = item.popularItem;
    commentTextarea.value = item.comment;
    isEditing = true;
    editingItemId = item.itemId;
    submitBtn.textContent = '✏️ Update Item';
    formTitle.textContent = '✏️ Edit Item';
    cancelEditBtn.style.display = 'inline-block';
    itemIdInput.disabled = true;
}

function validateForm(): { isValid: boolean; errorMessage: string } {
    const itemId = itemIdInput.value.trim();
    const itemName = itemNameInput.value.trim();
    const category = categorySelect.value;
    const quantity = parseInt(quantityInput.value);
    const price = parseFloat(priceInput.value);
    const supplier = supplierInput.value.trim();
    
    if (!isNotEmpty(itemId)) {
        return { isValid: false, errorMessage: 'Item ID is required' };
    }
    if (!isEditing && !isUniqueId(itemId)) {
        return { isValid: false, errorMessage: 'Item ID must be unique!' };
    }
    if (!isNotEmpty(itemName)) {
        return { isValid: false, errorMessage: 'Item Name is required' };
    }
    if (!category || category === '') {
        return { isValid: false, errorMessage: 'Please select a category' };
    }
    if (!isPositiveNumber(quantity)) {
        return { isValid: false, errorMessage: 'Quantity must be a positive number' };
    }
    if (!isPositiveNumber(price)) {
        return { isValid: false, errorMessage: 'Price must be a positive number' };
    }
    if (!isNotEmpty(supplier)) {
        return { isValid: false, errorMessage: 'Supplier name is required' };
    }
    return { isValid: true, errorMessage: '' };
}

function getFormData(): InventoryItem {
    const quantity = parseInt(quantityInput.value);
    return {
        itemId: itemIdInput.value.trim(),
        itemName: itemNameInput.value.trim(),
        category: categorySelect.value as Category,
        quantity: quantity,
        price: parseFloat(priceInput.value),
        supplierName: supplierInput.value.trim(),
        stockStatus: determineStockStatus(quantity),
        popularItem: popularItemSelect.value as PopularStatus,
        comment: commentTextarea.value.trim()
    };
}

function addItem(item: InventoryItem): boolean {
    if (inventory.some(existingItem => existingItem.itemId === item.itemId)) {
        showMessage(`Item ID ${item.itemId} already exists!`, 'error');
        return false;
    }
    inventory.push(item);
    showMessage(`✅ Item "${item.itemName}" added!`, 'success');
    return true;
}

function updateItem(updatedItem: InventoryItem): boolean {
    const index = inventory.findIndex(item => item.itemId === updatedItem.itemId);
    if (index === -1) return false;
    inventory[index] = updatedItem;
    showMessage(`✏️ Item "${updatedItem.itemName}" updated!`, 'success');
    return true;
}

function deleteItem(itemId: string): boolean {
    const index = inventory.findIndex(item => item.itemId === itemId);
    if (index === -1) return false;
    const itemName = inventory[index].itemName;
    inventory.splice(index, 1);
    showMessage(`🗑️ Item "${itemName}" deleted!`, 'success');
    return true;
}

function searchItems(searchTerm: string): InventoryItem[] {
    if (!searchTerm.trim()) return [...inventory];
    const term = searchTerm.toLowerCase().trim();
    return inventory.filter(item => item.itemName.toLowerCase().includes(term));
}

function getPopularItems(): InventoryItem[] {
    return inventory.filter(item => item.popularItem === 'Yes');
}

function escapeHtml(str: string): string {
    if (!str) return '';
    return str.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
}

function renderTable(): void {
    let itemsToDisplay: InventoryItem[] = [];
    if (showingPopularOnly) {
        itemsToDisplay = getPopularItems();
    } else if (currentSearchTerm) {
        itemsToDisplay = searchItems(currentSearchTerm);
    } else {
        itemsToDisplay = [...inventory];
    }
    
    tableBody.innerHTML = '';
    if (itemsToDisplay.length === 0) {
        tableBody.innerHTML = `<tr><td colspan="10" class="empty-message">No items found.</td></tr>`;
        return;
    }
    
    itemsToDisplay.forEach(item => {
        const row = tableBody.insertRow();
        row.innerHTML = `
            <td>${escapeHtml(item.itemId)}</td>
            <td><strong>${escapeHtml(item.itemName)}</strong></td>
            <td>${escapeHtml(item.category)}</td>
            <td>${item.quantity}</td>
            <td>$${item.price.toFixed(2)}</td>
            <td>${escapeHtml(item.supplierName)}</td>
            <td>${item.stockStatus}</td>
            <td>${item.popularItem === 'Yes' ? '⭐ Yes' : 'No'}</td>
            <td>${escapeHtml(item.comment || '-')}</td>
            <td>
                <button class="edit-btn" data-id="${item.itemId}">✏️ Edit</button>
                <button class="delete-btn" data-id="${item.itemId}">🗑️ Delete</button>
            </td>
        `;
    });
    
    document.querySelectorAll('.edit-btn').forEach(btn => {
        btn.addEventListener('click', (e) => {
            const id = (e.target as HTMLButtonElement).getAttribute('data-id');
            if (id) handleEditClick(id);
        });
    });
    
    document.querySelectorAll('.delete-btn').forEach(btn => {
        btn.addEventListener('click', (e) => {
            const id = (e.target as HTMLButtonElement).getAttribute('data-id');
            if (id) handleDeleteClick(id);
        });
    });
}

function handleEditClick(itemId: string): void {
    const item = inventory.find(i => i.itemId === itemId);
    if (item) populateFormForEdit(item);
}

function handleDeleteClick(itemId: string): void {
    const item = inventory.find(i => i.itemId === itemId);
    if (item) {
        pendingDeleteId = itemId;
        deleteItemNameSpan.textContent = item.itemName;
        confirmModal.style.display = 'flex';
    }
}

function executeDelete(): void {
    if (pendingDeleteId) {
        deleteItem(pendingDeleteId);
        renderTable();
        confirmModal.style.display = 'none';
        pendingDeleteId = null;
    }
}

function closeModal(): void {
    confirmModal.style.display = 'none';
    pendingDeleteId = null;
}

function handleFormSubmit(event: Event): void {
    event.preventDefault();
    const validation = validateForm();
    if (!validation.isValid) {
        showMessage(validation.errorMessage, 'error');
        return;
    }
    const formData = getFormData();
    let success = false;
    if (isEditing && editingItemId) {
        formData.itemId = editingItemId;
        success = updateItem(formData);
    } else {
        success = addItem(formData);
    }
    if (success) {
        resetForm();
        showingPopularOnly = false;
        currentSearchTerm = '';
        searchInput.value = '';
        renderTable();
    }
}

function handleSearch(): void {
    currentSearchTerm = searchInput.value;
    showingPopularOnly = false;
    renderTable();
}

function handleResetSearch(): void {
    currentSearchTerm = '';
    showingPopularOnly = false;
    searchInput.value = '';
    renderTable();
    showMessage('Showing all items', 'success');
}

function handleShowAll(): void {
    currentSearchTerm = '';
    showingPopularOnly = false;
    searchInput.value = '';
    renderTable();
    showMessage(`Showing all ${inventory.length} items`, 'success');
}

function handleShowPopular(): void {
    showingPopularOnly = true;
    currentSearchTerm = '';
    searchInput.value = '';
    renderTable();
    showMessage(`Showing ${getPopularItems().length} popular items`, 'success');
}

function handleCancelEdit(): void {
    resetForm();
    showMessage('Edit cancelled', 'success');
}

function loadSampleData(): void {
    inventory = [
        { itemId: 'ITM-001', itemName: 'MacBook Pro 14"', category: 'Electronics', quantity: 15, price: 1999.99, supplierName: 'Apple Inc.', stockStatus: 'In Stock', popularItem: 'Yes', comment: 'Latest M3 chip' },
        { itemId: 'ITM-002', itemName: 'Leather Office Chair', category: 'Furniture', quantity: 3, price: 299.99, supplierName: 'IKEA', stockStatus: 'Low Stock', popularItem: 'Yes', comment: 'Ergonomic' },
        { itemId: 'ITM-003', itemName: 'Wireless Mouse', category: 'Electronics', quantity: 0, price: 29.99, supplierName: 'Logitech', stockStatus: 'Out of Stock', popularItem: 'No', comment: '' },
        { itemId: 'ITM-004', itemName: 'Cotton T-Shirt', category: 'Clothing', quantity: 50, price: 19.99, supplierName: 'Uniqlo', stockStatus: 'In Stock', popularItem: 'No', comment: '' }
    ];
    renderTable();
    showMessage('Sample data loaded!', 'success');
}

function init(): void {
    itemForm.addEventListener('submit', handleFormSubmit);
    cancelEditBtn.addEventListener('click', handleCancelEdit);
    searchBtn.addEventListener('click', handleSearch);
    resetSearchBtn.addEventListener('click', handleResetSearch);
    showAllBtn.addEventListener('click', handleShowAll);
    showPopularBtn.addEventListener('click', handleShowPopular);
    confirmDeleteBtn.addEventListener('click', executeDelete);
    cancelDeleteBtn.addEventListener('click', closeModal);
    confirmModal.addEventListener('click', (e) => { if (e.target === confirmModal) closeModal(); });
    loadSampleData();
}

init();