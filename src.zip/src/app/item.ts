export interface Item { id: number; name: string; category: string; quantity: number; price: number; supplier: string; stockStatus: string; popular: string; comment: string; } 
