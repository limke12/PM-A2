import { Component } from '@angular/core';
import { InventoryService, Item } from '../inventory.service';

@Component({
  selector: 'app-search',
  standalone: false,
  templateUrl: './search.html',
  styleUrl: './search.css',
})
export class Search {
  searchTerm: string = '';
  searchResults: Item[] = [];
  selectedCategory: string = '';
  categories: string[] = ['全部', 'Electronics', 'Furniture', 'Clothing', 'Tools', 'Miscellaneous'];

  constructor(private inventoryService: InventoryService) {}

  search(): void {
    if (this.searchTerm.trim() === '') {
      this.searchResults = [];
      return;
    }
    
    let results = this.inventoryService.searchItems(this.searchTerm);
    
    // 按类别筛选
    if (this.selectedCategory && this.selectedCategory !== '全部') {
      results = results.filter(item => item.category === this.selectedCategory);
    }
    
    this.searchResults = results;
  }

  clearSearch(): void {
    this.searchTerm = '';
    this.selectedCategory = '';
    this.searchResults = [];
  }

  getStockStatusClass(status: string): string {
    return status === 'Low Stock' ? 'low-stock' : '';
  }
}