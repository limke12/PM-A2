import { Component, OnInit } from '@angular/core';
import { InventoryService, Item } from '../inventory.service';

@Component({
  selector: 'app-home',
  standalone: false,
  templateUrl: './home.html',
  styleUrl: './home.css',
})
export class Home implements OnInit {
  popularItems: Item[] = [];

  constructor(private inventoryService: InventoryService) {}

  ngOnInit(): void {
    this.popularItems = this.inventoryService.getPopularItems();
  }
}