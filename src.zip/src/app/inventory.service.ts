import { Injectable } from '@angular/core'; 
 
export interface Item { 
  id: number; 
  name: string; 
  category: string; 
  quantity: number; 
  price: number; 
  supplier: string; 
  stockStatus: string; 
  popular: string; 
  comment: string; 
} 
 
@Injectable({ 
  providedIn: 'root' 
}) 
export class InventoryService { 
  private items: Item[] = []; 
  private nextId = 1; 
 
  constructor() { 
    this.addSampleData(); 
  } 
 
  private addSampleData() { 
    const sampleItems = [ 
      { name: 'Laptop', category: 'Electronics', quantity: 10, price: 999, supplier: 'Dell', stockStatus: 'In Stock', popular: 'Yes', comment: 'Good condition' }, 
      { name: 'Desk Chair', category: 'Furniture', quantity: 5, price: 150, supplier: 'IKEA', stockStatus: 'Low Stock', popular: 'No', comment: '' }, 
      { name: 'Hammer', category: 'Tools', quantity: 20, price: 15, supplier: 'Stanley', stockStatus: 'In Stock', popular: 'No', comment: '' } 
    ]; 
    sampleItems.forEach(item => { 
      this.addItem(item); 
    }); 
  } 
 
  getItems(): Item[] { 
    return [...this.items]; 
  } 
 
  addItem(item: any): Item { 
    const newItem: Item = { 
      ...item, 
      id: this.nextId++ 
    }; 
    this.items.push(newItem); 
    return newItem; 
  } 
 
  updateItem(id: number, updatedData: any): boolean { 
    const index = this.items.findIndex(item => item.id === id); 
    if (index !== -1) { 
      this.items[index] = { ...this.items[index], ...updatedData }; 
      return true; 
    } 
    return false; 
  } 
 
  deleteItem(id: number): boolean { 
    const index = this.items.findIndex(item => item.id === id); 
    if (index !== -1) { 
      this.items.splice(index, 1); 
      return true; 
    } 
    return false; 
  } 
 
  searchItems(searchTerm: string): Item[] { 
    const term = searchTerm.toLowerCase(); 
    return this.items.filter(item => item.name.toLowerCase().includes(term)); 
  } 
 
  getPopularItems(): Item[] { 
    return this.items.filter(item => item.popular === 'Yes'); 
  } 
} 
