import { Component, OnInit } from '@angular/core';
import { InventoryService } from '../inventory.service';  // 确保路径正确
import { Item } from '../item';  // 确保路径正确

@Component({
  selector: 'app-inventory',
  standalone: false,
  templateUrl: './inventory.html',
  styleUrl: './inventory.css',
})
export class Inventory implements OnInit {
  items: Item[] = [];
  editingItem: Item | null = null;
  
  // 表单数据
  newItem = {
    name: '',
    category: '',
    quantity: 0,
    price: 0,
    supplier: '',
    stockStatus: 'In Stock',
    popular: 'No',
    comment: ''
  };

  categories = ['Electronics', 'Furniture', 'Clothing', 'Tools', 'Miscellaneous'];
  stockStatuses = ['In Stock', 'Low Stock', 'Out of Stock'];
  popularOptions = ['Yes', 'No'];

  constructor(private inventoryService: InventoryService) {}

  ngOnInit(): void {
    this.loadItems();
  }

  loadItems(): void {
    this.items = this.inventoryService.getItems();
  }

  addItem(): void {
    if (!this.validateForm()) {
      alert('请填写所有必填字段');
      return;
    }

    this.inventoryService.addItem(this.newItem);
    this.resetForm();
    this.loadItems();
    alert('物品添加成功！');
  }

  editItem(item: Item): void {
    this.editingItem = { ...item };
  }

  updateItem(): void {
    if (this.editingItem) {
      this.inventoryService.updateItem(this.editingItem.id, this.editingItem);
      this.editingItem = null;
      this.loadItems();
      alert('物品更新成功！');
    }
  }

  deleteItem(id: number, name: string): void {
    if (confirm(`确定要删除物品 "${name}" 吗？`)) {
      this.inventoryService.deleteItem(id);
      this.loadItems();
      alert('物品删除成功！');
    }
  }

  cancelEdit(): void {
    this.editingItem = null;
  }

  resetForm(): void {
    this.newItem = {
      name: '',
      category: '',
      quantity: 0,
      price: 0,
      supplier: '',
      stockStatus: 'In Stock',
      popular: 'No',
      comment: ''
    };
  }

  validateForm(): boolean {
    return this.newItem.name.trim() !== '' &&
           this.newItem.category !== '' &&
           this.newItem.quantity > 0 &&
           this.newItem.price > 0 &&
           this.newItem.supplier.trim() !== '';
  }
}