import { Component } from '@angular/core';

@Component({
  selector: 'app-fed',
  standalone: false,
  templateUrl: './fed.html',
  styleUrl: './fed.css',
})
export class Fed {}
