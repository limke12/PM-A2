import { ComponentFixture, TestBed } from '@angular/core/testing';

import { Fed } from './fed';

describe('Fed', () => {
  let component: Fed;
  let fixture: ComponentFixture<Fed>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [Fed],
    }).compileComponents();

    fixture = TestBed.createComponent(Fed);
    component = fixture.componentInstance;
    await fixture.whenStable();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
